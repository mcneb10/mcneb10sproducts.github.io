echo Starting
java -jar Mcneb10sVideoPlayer.jar