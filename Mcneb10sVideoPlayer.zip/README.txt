TO INSTALL;
Make a folder in program files(x86) drag the jar file and sh file in to the folder; then make a shortcut for the sh file and put it on your desktop and your done!